package com.horadoonibus.helpers;

/**
 * Created by Wolszczak on 27/06/2019.
 */
public class Utils {

    public static final String AUTH_KEY = "79d47";

}
